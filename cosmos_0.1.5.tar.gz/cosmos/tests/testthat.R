library(testthat)
library(cosmos)

test_check("cosmos")
